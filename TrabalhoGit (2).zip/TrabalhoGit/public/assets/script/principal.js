async function getGitHubProfile(RobsonMarcolino) {
  const url = `https://api.github.com/users/${RobsonMarcolino}`;

  try {
      const response = await fetch(url);
      if (!response.ok) {
          throw new Error('Erro ao buscar perfil do GitHub');
      }
      const profile = await response.json();
      return profile;
  } catch (error) {
      console.error('Erro na requisição de perfil do GitHub:', error);
      return null;
  }
}

function updateProfile(profile) {
  if (!profile) {
      console.error('Perfil não encontrado');
      return;
  }

  const fotoPerfil = document.getElementById('fotoPerfil');
  if (fotoPerfil) {
      fotoPerfil.src = profile.avatar_url;
      fotoPerfil.alt = `Foto de ${profile.name}`;
  }

  const nomePerfil = document.getElementById('nomePerfil');
  if (nomePerfil) {
      nomePerfil.textContent = profile.name || profile.login;
  }

  const bio = document.getElementById('bio');
  if (bio) {
      bio.textContent = profile.bio || 'Sem descrição';
  }
}

async function main() {
  const username = 'RobsonMarcolino'; // Nome de usuário do GitHub

  // Buscar o perfil do GitHub
  const profile = await getGitHubProfile(username);

  // Atualizar os dados do perfil na página
  updateProfile(profile);
}

// Chamar a função principal ao carregar a página
window.onload = main;